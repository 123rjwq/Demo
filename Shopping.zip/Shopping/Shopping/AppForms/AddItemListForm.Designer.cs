﻿namespace Shopping.AppForms
{
    partial class AddItemListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label nameLabel;
            System.Windows.Forms.Label quantityLabel;
            System.Windows.Forms.Label label1;
            this.shopsTableAdapter = new Shopping.ShoppingDataSetTableAdapters.ShopsTableAdapter();
            this.shoppingListsTableAdapter = new Shopping.ShoppingDataSetTableAdapters.ShoppingListsTableAdapter();
            this.shopsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shoppingDataSet = new Shopping.ShoppingDataSet();
            this.shoppingListsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tableAdapterManager = new Shopping.ShoppingDataSetTableAdapters.TableAdapterManager();
            this.commentHintAttentionFont = new System.Windows.Forms.Label();
            this.saveButtonAttentionBackground = new System.Windows.Forms.Button();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.promoCodesBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.promoCodesTableAdapter = new Shopping.ShoppingDataSetTableAdapters.PromoCodesTableAdapter();
            this.shoppingListItemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shoppingListItemsTableAdapter = new Shopping.ShoppingDataSetTableAdapters.ShoppingListItemsTableAdapter();
            this.nameTextBox = new System.Windows.Forms.TextBox();
            this.quantityNumericUpDown = new System.Windows.Forms.NumericUpDown();
            this.commentTextBox1 = new System.Windows.Forms.TextBox();
            nameLabel = new System.Windows.Forms.Label();
            quantityLabel = new System.Windows.Forms.Label();
            label1 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.shopsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.promoCodesBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListItemsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityNumericUpDown)).BeginInit();
            this.SuspendLayout();
            // 
            // shopsTableAdapter
            // 
            this.shopsTableAdapter.ClearBeforeFill = true;
            // 
            // shoppingListsTableAdapter
            // 
            this.shoppingListsTableAdapter.ClearBeforeFill = true;
            // 
            // shopsBindingSource
            // 
            this.shopsBindingSource.DataMember = "Shops";
            this.shopsBindingSource.DataSource = this.shoppingDataSet;
            // 
            // shoppingDataSet
            // 
            this.shoppingDataSet.DataSetName = "ShoppingDataSet";
            this.shoppingDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // shoppingListsBindingSource
            // 
            this.shoppingListsBindingSource.DataMember = "ShoppingLists";
            this.shoppingListsBindingSource.DataSource = this.shoppingDataSet;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.PromoCodesTableAdapter = null;
            this.tableAdapterManager.ShoppingListItemsTableAdapter = null;
            this.tableAdapterManager.ShoppingListsTableAdapter = this.shoppingListsTableAdapter;
            this.tableAdapterManager.ShopsTableAdapter = this.shopsTableAdapter;
            this.tableAdapterManager.UpdateOrder = Shopping.ShoppingDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // commentHintAttentionFont
            // 
            this.commentHintAttentionFont.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.commentHintAttentionFont.AutoSize = true;
            this.commentHintAttentionFont.Location = new System.Drawing.Point(514, 285);
            this.commentHintAttentionFont.Name = "commentHintAttentionFont";
            this.commentHintAttentionFont.Size = new System.Drawing.Size(306, 25);
            this.commentHintAttentionFont.TabIndex = 7;
            this.commentHintAttentionFont.Text = "*необязателен к заполнению";
            // 
            // saveButtonAttentionBackground
            // 
            this.saveButtonAttentionBackground.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.saveButtonAttentionBackground.Location = new System.Drawing.Point(167, 347);
            this.saveButtonAttentionBackground.Name = "saveButtonAttentionBackground";
            this.saveButtonAttentionBackground.Size = new System.Drawing.Size(653, 66);
            this.saveButtonAttentionBackground.TabIndex = 6;
            this.saveButtonAttentionBackground.Text = "Сохранить";
            this.saveButtonAttentionBackground.UseVisualStyleBackColor = true;
            this.saveButtonAttentionBackground.Click += new System.EventHandler(this.saveButtonAttentionBackground_Click);
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(195, 36);
            this.titleLabelAttentionFont.Margin = new System.Windows.Forms.Padding(0);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(140, 25);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "Новый товар";
            // 
            // splitContainer
            // 
            this.splitContainer.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(label1);
            this.splitContainer.Panel2.Controls.Add(this.commentTextBox1);
            this.splitContainer.Panel2.Controls.Add(quantityLabel);
            this.splitContainer.Panel2.Controls.Add(this.quantityNumericUpDown);
            this.splitContainer.Panel2.Controls.Add(nameLabel);
            this.splitContainer.Panel2.Controls.Add(this.nameTextBox);
            this.splitContainer.Panel2.Controls.Add(this.commentHintAttentionFont);
            this.splitContainer.Panel2.Controls.Add(this.saveButtonAttentionBackground);
            this.splitContainer.Size = new System.Drawing.Size(1002, 728);
            this.splitContainer.SplitterDistance = 184;
            this.splitContainer.SplitterWidth = 5;
            this.splitContainer.TabIndex = 3;
            // 
            // pictureBox
            // 
            this.pictureBox.Image = global::Shopping.Properties.Resources.logo1;
            this.pictureBox.Location = new System.Drawing.Point(32, 36);
            this.pictureBox.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(120, 120);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox.TabIndex = 0;
            this.pictureBox.TabStop = false;
            // 
            // promoCodesBindingSource
            // 
            this.promoCodesBindingSource.DataMember = "PromoCodes";
            this.promoCodesBindingSource.DataSource = this.shoppingDataSet;
            // 
            // promoCodesTableAdapter
            // 
            this.promoCodesTableAdapter.ClearBeforeFill = true;
            // 
            // shoppingListItemsBindingSource
            // 
            this.shoppingListItemsBindingSource.DataMember = "ShoppingListItems";
            this.shoppingListItemsBindingSource.DataSource = this.shoppingDataSet;
            // 
            // shoppingListItemsTableAdapter
            // 
            this.shoppingListItemsTableAdapter.ClearBeforeFill = true;
            // 
            // nameLabel
            // 
            nameLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            nameLabel.AutoSize = true;
            nameLabel.Location = new System.Drawing.Point(162, 139);
            nameLabel.Name = "nameLabel";
            nameLabel.Size = new System.Drawing.Size(167, 25);
            nameLabel.TabIndex = 8;
            nameLabel.Text = "Наименование:";
            // 
            // nameTextBox
            // 
            this.nameTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.nameTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.shoppingListItemsBindingSource, "Name", true));
            this.nameTextBox.Location = new System.Drawing.Point(342, 136);
            this.nameTextBox.Name = "nameTextBox";
            this.nameTextBox.Size = new System.Drawing.Size(478, 31);
            this.nameTextBox.TabIndex = 9;
            // 
            // quantityLabel
            // 
            quantityLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            quantityLabel.AutoSize = true;
            quantityLabel.Location = new System.Drawing.Point(162, 197);
            quantityLabel.Name = "quantityLabel";
            quantityLabel.Size = new System.Drawing.Size(135, 25);
            quantityLabel.TabIndex = 10;
            quantityLabel.Text = "Количество:";
            // 
            // quantityNumericUpDown
            // 
            this.quantityNumericUpDown.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.quantityNumericUpDown.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.shoppingListItemsBindingSource, "Quantity", true));
            this.quantityNumericUpDown.Location = new System.Drawing.Point(342, 195);
            this.quantityNumericUpDown.Name = "quantityNumericUpDown";
            this.quantityNumericUpDown.Size = new System.Drawing.Size(478, 31);
            this.quantityNumericUpDown.TabIndex = 11;
            this.quantityNumericUpDown.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // commentTextBox1
            // 
            this.commentTextBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.commentTextBox1.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.shoppingListItemsBindingSource, "Comment", true));
            this.commentTextBox1.Location = new System.Drawing.Point(342, 259);
            this.commentTextBox1.Name = "commentTextBox1";
            this.commentTextBox1.Size = new System.Drawing.Size(478, 31);
            this.commentTextBox1.TabIndex = 13;
            // 
            // label1
            // 
            label1.Anchor = System.Windows.Forms.AnchorStyles.None;
            label1.AutoSize = true;
            label1.Location = new System.Drawing.Point(162, 257);
            label1.Name = "label1";
            label1.Size = new System.Drawing.Size(156, 25);
            label1.TabIndex = 14;
            label1.Text = "Комментарий:";
            // 
            // AddItemListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 728);
            this.Controls.Add(this.splitContainer);
            this.Name = "AddItemListForm";
            this.Text = "AddItemListForm";
            ((System.ComponentModel.ISupportInitialize)(this.shopsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListsBindingSource)).EndInit();
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.promoCodesBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListItemsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.quantityNumericUpDown)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private ShoppingDataSetTableAdapters.ShopsTableAdapter shopsTableAdapter;
        private ShoppingDataSetTableAdapters.ShoppingListsTableAdapter shoppingListsTableAdapter;
        private System.Windows.Forms.BindingSource shopsBindingSource;
        private ShoppingDataSet shoppingDataSet;
        private System.Windows.Forms.BindingSource shoppingListsBindingSource;
        private ShoppingDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Label commentHintAttentionFont;
        private System.Windows.Forms.Button saveButtonAttentionBackground;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.BindingSource promoCodesBindingSource;
        private ShoppingDataSetTableAdapters.PromoCodesTableAdapter promoCodesTableAdapter;
        private System.Windows.Forms.BindingSource shoppingListItemsBindingSource;
        private ShoppingDataSetTableAdapters.ShoppingListItemsTableAdapter shoppingListItemsTableAdapter;
        private System.Windows.Forms.TextBox commentTextBox1;
        private System.Windows.Forms.NumericUpDown quantityNumericUpDown;
        private System.Windows.Forms.TextBox nameTextBox;
    }
}