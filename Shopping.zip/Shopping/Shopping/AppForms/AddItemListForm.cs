﻿using System;
using System.Windows.Forms;
using Shopping.Models;

namespace Shopping.AppForms
{
    public partial class AddItemListForm : Form
    {

        private int _listId = 0;
        public AddItemListForm(int listId)
        {
            InitializeComponent();
            _listId = listId;
        }

        private void saveButtonAttentionBackground_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(nameTextBox.Text))
                {
                    MessageBox.Show("Введите название товара!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    nameTextBox.Focus();
                    return;
                }

                if (quantityNumericUpDown.Value > 100)
                {
                    MessageBox.Show("Количество должно быть меньше 100!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    quantityNumericUpDown.Focus();
                    return;
                }

                var newItem = new ShoppingListItem
                {
                    Name = nameTextBox.Text.Trim(),
                    Quantity = (int)quantityNumericUpDown.Value,
                    Comment = string.IsNullOrWhiteSpace(commentTextBox1.Text) ? null : commentTextBox1.Text.Trim(),
                    ListId = _listId
                };

                Program.context.ShoppingListItems.Add(newItem);
                Program.context.SaveChanges();

                MessageBox.Show("Товар успешно добавлен!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
