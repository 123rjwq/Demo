﻿namespace Shopping.AppForms
{
    partial class CreateUpdateListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label shopIdLabel;
            System.Windows.Forms.Label dateLabel;
            System.Windows.Forms.Label commentLabel;
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.commentHintAttentionFont = new System.Windows.Forms.Label();
            this.saveButtonAttentionBackground = new System.Windows.Forms.Button();
            this.shopIdComboBox = new System.Windows.Forms.ComboBox();
            this.shoppingListsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shoppingDataSet = new Shopping.ShoppingDataSet();
            this.shopsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.dateDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.commentTextBox = new System.Windows.Forms.TextBox();
            this.shoppingListsTableAdapter = new Shopping.ShoppingDataSetTableAdapters.ShoppingListsTableAdapter();
            this.tableAdapterManager = new Shopping.ShoppingDataSetTableAdapters.TableAdapterManager();
            this.shopsTableAdapter = new Shopping.ShoppingDataSetTableAdapters.ShopsTableAdapter();
            shopIdLabel = new System.Windows.Forms.Label();
            dateLabel = new System.Windows.Forms.Label();
            commentLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // shopIdLabel
            // 
            shopIdLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            shopIdLabel.AutoSize = true;
            shopIdLabel.Location = new System.Drawing.Point(159, 223);
            shopIdLabel.Name = "shopIdLabel";
            shopIdLabel.Size = new System.Drawing.Size(103, 25);
            shopIdLabel.TabIndex = 0;
            shopIdLabel.Text = "Магазин:";
            // 
            // dateLabel
            // 
            dateLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            dateLabel.AutoSize = true;
            dateLabel.Location = new System.Drawing.Point(159, 284);
            dateLabel.Name = "dateLabel";
            dateLabel.Size = new System.Drawing.Size(68, 25);
            dateLabel.TabIndex = 2;
            dateLabel.Text = "Дата:";
            // 
            // commentLabel
            // 
            commentLabel.Anchor = System.Windows.Forms.AnchorStyles.None;
            commentLabel.AutoSize = true;
            commentLabel.Location = new System.Drawing.Point(159, 339);
            commentLabel.Name = "commentLabel";
            commentLabel.Size = new System.Drawing.Size(156, 25);
            commentLabel.TabIndex = 4;
            commentLabel.Text = "Комментарий:";
            // 
            // splitContainer
            // 
            this.splitContainer.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.commentHintAttentionFont);
            this.splitContainer.Panel2.Controls.Add(this.saveButtonAttentionBackground);
            this.splitContainer.Panel2.Controls.Add(shopIdLabel);
            this.splitContainer.Panel2.Controls.Add(this.shopIdComboBox);
            this.splitContainer.Panel2.Controls.Add(dateLabel);
            this.splitContainer.Panel2.Controls.Add(this.dateDateTimePicker);
            this.splitContainer.Panel2.Controls.Add(commentLabel);
            this.splitContainer.Panel2.Controls.Add(this.commentTextBox);
            this.splitContainer.Size = new System.Drawing.Size(1002, 884);
            this.splitContainer.SplitterDistance = 184;
            this.splitContainer.SplitterWidth = 5;
            this.splitContainer.TabIndex = 2;
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(195, 36);
            this.titleLabelAttentionFont.Margin = new System.Windows.Forms.Padding(0);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(152, 25);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "Новый список";
            // 
            // pictureBox
            // 
            this.pictureBox.Image = global::Shopping.Properties.Resources.logo1;
            this.pictureBox.Location = new System.Drawing.Point(32, 36);
            this.pictureBox.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(120, 120);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox.TabIndex = 0;
            this.pictureBox.TabStop = false;
            // 
            // commentHintAttentionFont
            // 
            this.commentHintAttentionFont.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.commentHintAttentionFont.AutoSize = true;
            this.commentHintAttentionFont.Location = new System.Drawing.Point(511, 367);
            this.commentHintAttentionFont.Name = "commentHintAttentionFont";
            this.commentHintAttentionFont.Size = new System.Drawing.Size(306, 25);
            this.commentHintAttentionFont.TabIndex = 7;
            this.commentHintAttentionFont.Text = "*необязателен к заполнению";
            // 
            // saveButtonAttentionBackground
            // 
            this.saveButtonAttentionBackground.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.saveButtonAttentionBackground.Location = new System.Drawing.Point(164, 429);
            this.saveButtonAttentionBackground.Name = "saveButtonAttentionBackground";
            this.saveButtonAttentionBackground.Size = new System.Drawing.Size(653, 66);
            this.saveButtonAttentionBackground.TabIndex = 6;
            this.saveButtonAttentionBackground.Text = "Сохранить";
            this.saveButtonAttentionBackground.UseVisualStyleBackColor = true;
            this.saveButtonAttentionBackground.Click += new System.EventHandler(this.saveButtonAttentionBackground_Click);
            // 
            // shopIdComboBox
            // 
            this.shopIdComboBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.shopIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.shoppingListsBindingSource, "ShopId", true));
            this.shopIdComboBox.DataSource = this.shopsBindingSource;
            this.shopIdComboBox.DisplayMember = "Name";
            this.shopIdComboBox.FormattingEnabled = true;
            this.shopIdComboBox.Location = new System.Drawing.Point(339, 220);
            this.shopIdComboBox.Name = "shopIdComboBox";
            this.shopIdComboBox.Size = new System.Drawing.Size(478, 33);
            this.shopIdComboBox.TabIndex = 1;
            this.shopIdComboBox.ValueMember = "IdShop";
            // 
            // shoppingListsBindingSource
            // 
            this.shoppingListsBindingSource.DataMember = "ShoppingLists";
            this.shoppingListsBindingSource.DataSource = this.shoppingDataSet;
            // 
            // shoppingDataSet
            // 
            this.shoppingDataSet.DataSetName = "ShoppingDataSet";
            this.shoppingDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // shopsBindingSource
            // 
            this.shopsBindingSource.DataMember = "Shops";
            this.shopsBindingSource.DataSource = this.shoppingDataSet;
            // 
            // dateDateTimePicker
            // 
            this.dateDateTimePicker.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.dateDateTimePicker.DataBindings.Add(new System.Windows.Forms.Binding("Value", this.shoppingListsBindingSource, "Date", true));
            this.dateDateTimePicker.Location = new System.Drawing.Point(339, 279);
            this.dateDateTimePicker.MaxDate = new System.DateTime(2027, 12, 31, 0, 0, 0, 0);
            this.dateDateTimePicker.Name = "dateDateTimePicker";
            this.dateDateTimePicker.Size = new System.Drawing.Size(478, 31);
            this.dateDateTimePicker.TabIndex = 3;
            this.dateDateTimePicker.Value = new System.DateTime(2025, 2, 3, 21, 9, 45, 0);
            this.dateDateTimePicker.ValueChanged += new System.EventHandler(this.dateDateTimePicker_ValueChanged);
            // 
            // commentTextBox
            // 
            this.commentTextBox.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.commentTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.shoppingListsBindingSource, "Comment", true));
            this.commentTextBox.Location = new System.Drawing.Point(339, 336);
            this.commentTextBox.MaxLength = 250;
            this.commentTextBox.Name = "commentTextBox";
            this.commentTextBox.Size = new System.Drawing.Size(478, 31);
            this.commentTextBox.TabIndex = 5;
            // 
            // shoppingListsTableAdapter
            // 
            this.shoppingListsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.PromoCodesTableAdapter = null;
            this.tableAdapterManager.ShoppingListItemsTableAdapter = null;
            this.tableAdapterManager.ShoppingListsTableAdapter = this.shoppingListsTableAdapter;
            this.tableAdapterManager.ShopsTableAdapter = this.shopsTableAdapter;
            this.tableAdapterManager.UpdateOrder = Shopping.ShoppingDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // shopsTableAdapter
            // 
            this.shopsTableAdapter.ClearBeforeFill = true;
            // 
            // CreateUpdateListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1002, 884);
            this.Controls.Add(this.splitContainer);
            this.Name = "CreateUpdateListForm";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.CreateUpdateListForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            this.splitContainer.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox;
        private ShoppingDataSet shoppingDataSet;
        private System.Windows.Forms.BindingSource shoppingListsBindingSource;
        private ShoppingDataSetTableAdapters.ShoppingListsTableAdapter shoppingListsTableAdapter;
        private ShoppingDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.Button saveButtonAttentionBackground;
        private System.Windows.Forms.ComboBox shopIdComboBox;
        private System.Windows.Forms.DateTimePicker dateDateTimePicker;
        private System.Windows.Forms.TextBox commentTextBox;
        private System.Windows.Forms.Label commentHintAttentionFont;
        private ShoppingDataSetTableAdapters.ShopsTableAdapter shopsTableAdapter;
        private System.Windows.Forms.BindingSource shopsBindingSource;
    }
}