﻿using System;
using System.Linq;
using System.Windows.Forms;
using Shopping.Models;

namespace Shopping.AppForms
{
    public partial class CreateUpdateListForm : Form
    {
        private readonly ShoppingList _shoppingList;

        public CreateUpdateListForm()
        {
            InitializeComponent();
            InitializeDatePicker();

            _shoppingList = new ShoppingList();
            Program.context.ShoppingLists.Add(_shoppingList);
        }

        public CreateUpdateListForm(ShoppingList shoppingList)
        {
            InitializeComponent();
            InitializeDatePicker();

            _shoppingList = shoppingList ?? throw new ArgumentNullException(nameof(shoppingList));
        }

        private void InitializeDatePicker()
        {
            dateDateTimePicker.MinDate = DateTime.Now;
            dateDateTimePicker.MaxDate = new DateTime(DateTime.Now.Year + 1, 12, 31);
        }

        private void CreateUpdateListForm_Load(object sender, EventArgs e)
        {
            shopIdComboBox.DataSource = Program.context.Shops.ToList();
            shopIdComboBox.DisplayMember = "Name";
            shopIdComboBox.ValueMember = "IdShop";

            if (!_shoppingList.isNew())
            {
                shoppingListsBindingSource.DataSource = _shoppingList;
                shopIdComboBox.SelectedValue = _shoppingList.ShopId;
            }
        }

        private void saveButtonAttentionBackground_Click(object sender, EventArgs e)
        {
            FillModelFields();

            if (_shoppingList.isNew())
                Program.context.ShoppingLists.Add(_shoppingList);

            if (MessageBox.Show("Сохранить?", "Подтверждение", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.No)
                return;

            SaveChangesWithMessage();
        }

        private void FillModelFields()
        {
            if (shopIdComboBox.SelectedValue is int shopId)
            {
                _shoppingList.ShopId = shopId;
            }
            else
            {
                MessageBox.Show("Выберите магазин!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            _shoppingList.Date = dateDateTimePicker.Value.Date;
            _shoppingList.Comment = string.IsNullOrWhiteSpace(commentTextBox.Text) ? null : commentTextBox.Text.Trim();
            _shoppingList.Archived = false;
        }

        private void SaveChangesWithMessage()
        {
            try
            {
                Program.context.SaveChanges();
                MessageBox.Show("Данные сохранены", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
                DialogResult = DialogResult.OK;
                Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dateDateTimePicker_ValueChanged(object sender, EventArgs e)
        {
            if (dateDateTimePicker.Value < DateTime.Today || dateDateTimePicker.Value.Year > DateTime.Now.Year + 1)
            {
                MessageBox.Show("Дата должна быть в пределах от сегодня до года вперед!", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                dateDateTimePicker.Value = DateTime.Now;
            }
        }
    }
}