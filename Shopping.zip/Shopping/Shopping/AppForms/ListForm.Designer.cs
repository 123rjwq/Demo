﻿namespace Shopping.AppForms
{
    partial class ListForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.addListItemButtonAttentionFont = new System.Windows.Forms.Button();
            this.commentLabel = new System.Windows.Forms.Label();
            this.locationLabel = new System.Windows.Forms.Label();
            this.dateLabel = new System.Windows.Forms.Label();
            this.storeLabel = new System.Windows.Forms.Label();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.shoppingListItemsDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.rowNumber = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.shoppingListItemsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shoppingDataSet = new Shopping.ShoppingDataSet();
            this.shoppingListsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shoppingListsTableAdapter = new Shopping.ShoppingDataSetTableAdapters.ShoppingListsTableAdapter();
            this.tableAdapterManager = new Shopping.ShoppingDataSetTableAdapters.TableAdapterManager();
            this.shoppingListItemsTableAdapter = new Shopping.ShoppingDataSetTableAdapters.ShoppingListItemsTableAdapter();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListItemsDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListItemsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListsBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // splitContainer
            // 
            this.splitContainer.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.Controls.Add(this.addListItemButtonAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.commentLabel);
            this.splitContainer.Panel1.Controls.Add(this.locationLabel);
            this.splitContainer.Panel1.Controls.Add(this.dateLabel);
            this.splitContainer.Panel1.Controls.Add(this.storeLabel);
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.shoppingListItemsDataGridView);
            this.splitContainer.Panel2.Padding = new System.Windows.Forms.Padding(20, 0, 20, 20);
            this.splitContainer.Size = new System.Drawing.Size(1774, 1329);
            this.splitContainer.SplitterDistance = 184;
            this.splitContainer.SplitterWidth = 5;
            this.splitContainer.TabIndex = 2;
            // 
            // addListItemButtonAttentionFont
            // 
            this.addListItemButtonAttentionFont.Location = new System.Drawing.Point(494, 30);
            this.addListItemButtonAttentionFont.Name = "addListItemButtonAttentionFont";
            this.addListItemButtonAttentionFont.Size = new System.Drawing.Size(293, 57);
            this.addListItemButtonAttentionFont.TabIndex = 17;
            this.addListItemButtonAttentionFont.Text = "Добавить товар";
            this.addListItemButtonAttentionFont.UseVisualStyleBackColor = true;
            this.addListItemButtonAttentionFont.Click += new System.EventHandler(this.addListItemButtonAttentionFont_Click);
            // 
            // commentLabel
            // 
            this.commentLabel.AutoSize = true;
            this.commentLabel.Location = new System.Drawing.Point(1276, 131);
            this.commentLabel.Margin = new System.Windows.Forms.Padding(0);
            this.commentLabel.Name = "commentLabel";
            this.commentLabel.Size = new System.Drawing.Size(150, 25);
            this.commentLabel.TabIndex = 16;
            this.commentLabel.Text = "Комментарий\r\n";
            // 
            // locationLabel
            // 
            this.locationLabel.AutoSize = true;
            this.locationLabel.Location = new System.Drawing.Point(865, 131);
            this.locationLabel.Margin = new System.Windows.Forms.Padding(0);
            this.locationLabel.Name = "locationLabel";
            this.locationLabel.Size = new System.Drawing.Size(97, 25);
            this.locationLabel.TabIndex = 15;
            this.locationLabel.Text = "Локация";
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = true;
            this.dateLabel.Location = new System.Drawing.Point(451, 131);
            this.dateLabel.Margin = new System.Windows.Forms.Padding(0);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(62, 25);
            this.dateLabel.TabIndex = 14;
            this.dateLabel.Text = "Дата";
            // 
            // storeLabel
            // 
            this.storeLabel.AutoSize = true;
            this.storeLabel.Location = new System.Drawing.Point(195, 131);
            this.storeLabel.Margin = new System.Windows.Forms.Padding(0);
            this.storeLabel.Name = "storeLabel";
            this.storeLabel.Size = new System.Drawing.Size(97, 25);
            this.storeLabel.TabIndex = 13;
            this.storeLabel.Text = "Магазин";
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(195, 36);
            this.titleLabelAttentionFont.Margin = new System.Windows.Forms.Padding(0);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(253, 25);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "Редактирование списка";
            // 
            // pictureBox
            // 
            this.pictureBox.Image = global::Shopping.Properties.Resources.logo1;
            this.pictureBox.Location = new System.Drawing.Point(32, 36);
            this.pictureBox.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(120, 120);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox.TabIndex = 0;
            this.pictureBox.TabStop = false;
            // 
            // shoppingListItemsDataGridView
            // 
            this.shoppingListItemsDataGridView.AutoGenerateColumns = false;
            this.shoppingListItemsDataGridView.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.shoppingListItemsDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.shoppingListItemsDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.rowNumber,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5});
            this.shoppingListItemsDataGridView.DataSource = this.shoppingListItemsBindingSource;
            this.shoppingListItemsDataGridView.Dock = System.Windows.Forms.DockStyle.Fill;
            this.shoppingListItemsDataGridView.Location = new System.Drawing.Point(20, 0);
            this.shoppingListItemsDataGridView.Name = "shoppingListItemsDataGridView";
            this.shoppingListItemsDataGridView.RowHeadersWidth = 82;
            this.shoppingListItemsDataGridView.RowTemplate.Height = 33;
            this.shoppingListItemsDataGridView.Size = new System.Drawing.Size(1734, 1120);
            this.shoppingListItemsDataGridView.TabIndex = 0;
            this.shoppingListItemsDataGridView.CellValueChanged += new System.Windows.Forms.DataGridViewCellEventHandler(this.shoppingListItemsDataGridView_CellValueChanged);
            this.shoppingListItemsDataGridView.RowsAdded += new System.Windows.Forms.DataGridViewRowsAddedEventHandler(this.shoppingListItemsDataGridView_RowsAdded);
            this.shoppingListItemsDataGridView.RowValidated += new System.Windows.Forms.DataGridViewCellEventHandler(this.shoppingListItemsDataGridView_RowValidated);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "IdItem";
            this.dataGridViewTextBoxColumn1.HeaderText = "IdItem";
            this.dataGridViewTextBoxColumn1.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ListId";
            this.dataGridViewTextBoxColumn2.HeaderText = "ListId";
            this.dataGridViewTextBoxColumn2.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.Visible = false;
            // 
            // rowNumber
            // 
            this.rowNumber.HeaderText = "Номер";
            this.rowNumber.MinimumWidth = 10;
            this.rowNumber.Name = "rowNumber";
            this.rowNumber.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Name";
            this.dataGridViewTextBoxColumn3.HeaderText = "Название";
            this.dataGridViewTextBoxColumn3.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "Quantity";
            this.dataGridViewTextBoxColumn4.HeaderText = "Количество";
            this.dataGridViewTextBoxColumn4.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Comment";
            this.dataGridViewTextBoxColumn5.HeaderText = "Комментарий";
            this.dataGridViewTextBoxColumn5.MinimumWidth = 10;
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // shoppingListItemsBindingSource
            // 
            this.shoppingListItemsBindingSource.DataMember = "ShoppingListItems";
            this.shoppingListItemsBindingSource.DataSource = this.shoppingDataSet;
            // 
            // shoppingDataSet
            // 
            this.shoppingDataSet.DataSetName = "ShoppingDataSet";
            this.shoppingDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // shoppingListsBindingSource
            // 
            this.shoppingListsBindingSource.DataMember = "ShoppingLists";
            this.shoppingListsBindingSource.DataSource = this.shoppingDataSet;
            // 
            // shoppingListsTableAdapter
            // 
            this.shoppingListsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.PromoCodesTableAdapter = null;
            this.tableAdapterManager.ShoppingListItemsTableAdapter = this.shoppingListItemsTableAdapter;
            this.tableAdapterManager.ShoppingListsTableAdapter = this.shoppingListsTableAdapter;
            this.tableAdapterManager.ShopsTableAdapter = null;
            this.tableAdapterManager.UpdateOrder = Shopping.ShoppingDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // shoppingListItemsTableAdapter
            // 
            this.shoppingListItemsTableAdapter.ClearBeforeFill = true;
            // 
            // ListForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1774, 1329);
            this.Controls.Add(this.splitContainer);
            this.Name = "ListForm";
            this.Text = "ListForm";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.ListForm_FormClosed);
            this.Load += new System.EventHandler(this.ListForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListItemsDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListItemsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListsBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox;
        private ShoppingDataSet shoppingDataSet;
        private System.Windows.Forms.BindingSource shoppingListsBindingSource;
        private ShoppingDataSetTableAdapters.ShoppingListsTableAdapter shoppingListsTableAdapter;
        private ShoppingDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private ShoppingDataSetTableAdapters.ShoppingListItemsTableAdapter shoppingListItemsTableAdapter;
        private System.Windows.Forms.BindingSource shoppingListItemsBindingSource;
        private System.Windows.Forms.DataGridView shoppingListItemsDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn rowNumber;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.Label commentLabel;
        private System.Windows.Forms.Label locationLabel;
        private System.Windows.Forms.Label dateLabel;
        private System.Windows.Forms.Label storeLabel;
        private System.Windows.Forms.Button addListItemButtonAttentionFont;
    }
}