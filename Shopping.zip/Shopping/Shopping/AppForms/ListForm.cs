﻿using System;
using System.Linq;
using System.Windows.Forms;
using Shopping.Models;

namespace Shopping.AppForms
{
    public partial class ListForm : Form
    {
        private ShoppingList _shoppingList;

        public ListForm(ShoppingList shoppingList)
        {
            InitializeComponent();
            _shoppingList = shoppingList;

            shoppingListItemsDataGridView.RowsAdded += shoppingListItemsDataGridView_RowsAdded;

            SetLabels();
        }

        private void ListForm_Load(object sender, EventArgs e)
        {
            RefreshDataGrid();
        }

        private void RefreshDataGrid()
        {
            shoppingListItemsDataGridView.DataSource = null;
            shoppingListItemsDataGridView.DataSource = Program.context.ShoppingListItems
                .Where(item => item.ListId == _shoppingList.IdList)
                .ToList();
            shoppingListItemsDataGridView.Refresh();
            shoppingListItemsDataGridView.BindingContext = new BindingContext();
        }

        private void shoppingListItemsDataGridView_RowsAdded(object sender, DataGridViewRowsAddedEventArgs e)
        {
            for (int i = e.RowIndex; i < e.RowIndex + e.RowCount; i++)
            {
                shoppingListItemsDataGridView.Rows[i].Cells["rowNumber"].Value = i + 1; // Заполнение номера строки
            }
        }

        private void shoppingListItemsDataGridView_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = shoppingListItemsDataGridView.Rows[e.RowIndex];
            }
        }

        private void SetLabels()
        {
            storeLabel.Text = $"{_shoppingList.Shop.Name} + {_shoppingList.IdList}";
            dateLabel.Text = _shoppingList.Date.ToLongDateString();
            locationLabel.Text = _shoppingList.Shop.Location;
            commentLabel.Text = _shoppingList.Comment;
        }

        private void shoppingListItemsDataGridView_RowValidated(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.Validate();
                Program.context.SaveChanges();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void addListItemButtonAttentionFont_Click(object sender, EventArgs e)
        {
            AddItemListForm addItemListForm = new AddItemListForm(_shoppingList.IdList);
            DialogResult listSaved = addItemListForm.ShowDialog();
            if (listSaved == DialogResult.OK)
            {
                RefreshDataGrid();
            }
        }

        private void ListForm_FormClosed(object sender, FormClosedEventArgs e)
        {
            DialogResult = DialogResult.OK;
        }
    }
}