﻿namespace Shopping.AppForms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label shopIdLabel;
            this.flowLayoutPanel = new System.Windows.Forms.FlowLayoutPanel();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this.shopIdComboBox = new System.Windows.Forms.ComboBox();
            this.shoppingListsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shoppingDataSet = new Shopping.ShoppingDataSet();
            this.newPartnerAttentionBackground = new System.Windows.Forms.Button();
            this.titleLabelAttentionFont = new System.Windows.Forms.Label();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.shopsBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.shoppingListsTableAdapter = new Shopping.ShoppingDataSetTableAdapters.ShoppingListsTableAdapter();
            this.tableAdapterManager = new Shopping.ShoppingDataSetTableAdapters.TableAdapterManager();
            this.shopsTableAdapter = new Shopping.ShoppingDataSetTableAdapters.ShopsTableAdapter();
            this.shoppingListsBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            shopIdLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.Panel2.SuspendLayout();
            this.splitContainer.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopsBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListsBindingSource1)).BeginInit();
            this.SuspendLayout();
            // 
            // shopIdLabel
            // 
            shopIdLabel.AutoSize = true;
            shopIdLabel.Location = new System.Drawing.Point(590, 111);
            shopIdLabel.Name = "shopIdLabel";
            shopIdLabel.Size = new System.Drawing.Size(103, 25);
            shopIdLabel.TabIndex = 3;
            shopIdLabel.Text = "Магазин:";
            // 
            // flowLayoutPanel
            // 
            this.flowLayoutPanel.AutoScroll = true;
            this.flowLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel.Margin = new System.Windows.Forms.Padding(0);
            this.flowLayoutPanel.Name = "flowLayoutPanel";
            this.flowLayoutPanel.Size = new System.Drawing.Size(1774, 1140);
            this.flowLayoutPanel.TabIndex = 0;
            // 
            // splitContainer
            // 
            this.splitContainer.BackColor = System.Drawing.Color.Transparent;
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.FixedPanel = System.Windows.Forms.FixedPanel.Panel1;
            this.splitContainer.Location = new System.Drawing.Point(0, 0);
            this.splitContainer.Margin = new System.Windows.Forms.Padding(0);
            this.splitContainer.Name = "splitContainer";
            this.splitContainer.Orientation = System.Windows.Forms.Orientation.Horizontal;
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.AutoScroll = true;
            this.splitContainer.Panel1.Controls.Add(shopIdLabel);
            this.splitContainer.Panel1.Controls.Add(this.shopIdComboBox);
            this.splitContainer.Panel1.Controls.Add(this.newPartnerAttentionBackground);
            this.splitContainer.Panel1.Controls.Add(this.titleLabelAttentionFont);
            this.splitContainer.Panel1.Controls.Add(this.pictureBox);
            // 
            // splitContainer.Panel2
            // 
            this.splitContainer.Panel2.Controls.Add(this.flowLayoutPanel);
            this.splitContainer.Size = new System.Drawing.Size(1774, 1329);
            this.splitContainer.SplitterDistance = 184;
            this.splitContainer.SplitterWidth = 5;
            this.splitContainer.TabIndex = 1;
            // 
            // shopIdComboBox
            // 
            this.shopIdComboBox.DataBindings.Add(new System.Windows.Forms.Binding("SelectedValue", this.shoppingListsBindingSource, "ShopId", true));
            this.shopIdComboBox.FormattingEnabled = true;
            this.shopIdComboBox.Location = new System.Drawing.Point(698, 108);
            this.shopIdComboBox.Name = "shopIdComboBox";
            this.shopIdComboBox.Size = new System.Drawing.Size(224, 33);
            this.shopIdComboBox.TabIndex = 4;
            this.shopIdComboBox.SelectedIndexChanged += new System.EventHandler(this.shopIdComboBox_SelectedIndexChanged);
            // 
            // shoppingListsBindingSource
            // 
            this.shoppingListsBindingSource.DataMember = "ShoppingLists";
            this.shoppingListsBindingSource.DataSource = this.shoppingDataSet;
            // 
            // shoppingDataSet
            // 
            this.shoppingDataSet.DataSetName = "ShoppingDataSet";
            this.shoppingDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // newPartnerAttentionBackground
            // 
            this.newPartnerAttentionBackground.Location = new System.Drawing.Point(200, 88);
            this.newPartnerAttentionBackground.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.newPartnerAttentionBackground.Name = "newPartnerAttentionBackground";
            this.newPartnerAttentionBackground.Size = new System.Drawing.Size(251, 68);
            this.newPartnerAttentionBackground.TabIndex = 2;
            this.newPartnerAttentionBackground.Text = "Новый список";
            this.newPartnerAttentionBackground.UseVisualStyleBackColor = true;
            this.newPartnerAttentionBackground.Click += new System.EventHandler(this.newPartnerAttentionBackground_Click);
            // 
            // titleLabelAttentionFont
            // 
            this.titleLabelAttentionFont.AutoSize = true;
            this.titleLabelAttentionFont.Location = new System.Drawing.Point(195, 36);
            this.titleLabelAttentionFont.Margin = new System.Windows.Forms.Padding(0);
            this.titleLabelAttentionFont.Name = "titleLabelAttentionFont";
            this.titleLabelAttentionFont.Size = new System.Drawing.Size(185, 25);
            this.titleLabelAttentionFont.TabIndex = 1;
            this.titleLabelAttentionFont.Text = "Дневник питания";
            // 
            // pictureBox
            // 
            this.pictureBox.Image = global::Shopping.Properties.Resources.logo1;
            this.pictureBox.Location = new System.Drawing.Point(32, 36);
            this.pictureBox.Margin = new System.Windows.Forms.Padding(0);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(120, 120);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox.TabIndex = 0;
            this.pictureBox.TabStop = false;
            // 
            // shopsBindingSource
            // 
            this.shopsBindingSource.DataMember = "Shops";
            this.shopsBindingSource.DataSource = this.shoppingDataSet;
            // 
            // shoppingListsTableAdapter
            // 
            this.shoppingListsTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.PromoCodesTableAdapter = null;
            this.tableAdapterManager.ShoppingListItemsTableAdapter = null;
            this.tableAdapterManager.ShoppingListsTableAdapter = this.shoppingListsTableAdapter;
            this.tableAdapterManager.ShopsTableAdapter = this.shopsTableAdapter;
            this.tableAdapterManager.UpdateOrder = Shopping.ShoppingDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // shopsTableAdapter
            // 
            this.shopsTableAdapter.ClearBeforeFill = true;
            // 
            // shoppingListsBindingSource1
            // 
            this.shoppingListsBindingSource1.DataMember = "ShoppingLists";
            this.shoppingListsBindingSource1.DataSource = this.shoppingDataSet;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1774, 1329);
            this.Controls.Add(this.splitContainer);
            this.Name = "MainForm";
            this.Text = "MainForm";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.splitContainer.Panel1.ResumeLayout(false);
            this.splitContainer.Panel1.PerformLayout();
            this.splitContainer.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shopsBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.shoppingListsBindingSource1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.Button newPartnerAttentionBackground;
        private System.Windows.Forms.Label titleLabelAttentionFont;
        private System.Windows.Forms.PictureBox pictureBox;
        private ShoppingDataSet shoppingDataSet;
        private System.Windows.Forms.BindingSource shoppingListsBindingSource;
        private ShoppingDataSetTableAdapters.ShoppingListsTableAdapter shoppingListsTableAdapter;
        private ShoppingDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.ComboBox shopIdComboBox;
        private System.Windows.Forms.BindingSource shoppingListsBindingSource1;
        private ShoppingDataSetTableAdapters.ShopsTableAdapter shopsTableAdapter;
        private System.Windows.Forms.BindingSource shopsBindingSource;
    }
}