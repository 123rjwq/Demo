﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using Shopping.Models;
using Shopping.AppUserControls;
using System.Data.Entity;

namespace Shopping.AppForms
{
    public partial class MainForm : Form
    {
        public event EventHandler ControlUpdated;

        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            LoadShops();
            ShowShoppingLists();
        }

        private void LoadShops()
        {
            var shops = Program.context.Shops.ToList();
            shops.Insert(0, new Shop { IdShop = -1, Name = "Все магазины" });

            shopIdComboBox.DataSource = shops;
            shopIdComboBox.DisplayMember = "Name";
            shopIdComboBox.ValueMember = "IdShop";
            shopIdComboBox.SelectedValue = -1; // Фильтр "Все магазины" по умолчанию
        }

        private void ShowShoppingLists()
        {
            flowLayoutPanel.Controls.Clear();

            // Получаем списки покупок, сортируем по дате (новые сверху)
            var shoppingLists = Program.context.ShoppingLists
                .OrderByDescending(p => p.Date)
                .ToList();

            ArchiveExpiredLists(shoppingLists);

            // Фильтрация по магазину
            int? selectedShopId = shopIdComboBox.SelectedValue as int?;
            if (selectedShopId != -1)
            {
                shoppingLists = shoppingLists.Where(sl => sl.ShopId == selectedShopId).ToList();
            }

            // Отображение списков
            foreach (var shoppingList in shoppingLists.Where(sl => sl.Archived == false))
            {
                var control = new DiaryUserControl(shoppingList);
                control.ControlUpdated += OnControlUpdated;
                flowLayoutPanel.Controls.Add(control);
            }
        }

        private void ArchiveExpiredLists(List<ShoppingList> shoppingLists)
        {
            var today = DateTime.Today;
            var expiredLists = shoppingLists.Where(sl => sl.Date < today && sl.Archived == false).ToList();

            if (expiredLists.Any())
            {
                foreach (var shoppingList in expiredLists)
                {
                    shoppingList.Archived = true;
                    Program.context.Entry(shoppingList).State = EntityState.Modified;
                }
                Program.context.SaveChanges();
            }
        }

        private void OnControlUpdated(object sender, EventArgs e)
        {
            ShowShoppingLists();
        }

        private void newPartnerAttentionBackground_Click(object sender, EventArgs e)
        {
            var createUpdateListForm = new CreateUpdateListForm();
            if (createUpdateListForm.ShowDialog() == DialogResult.OK)
            {
                RefreshShoppingLists();
            }
        }

        public void RefreshShoppingLists()
        {
            flowLayoutPanel.Controls.Clear();
            ShowShoppingLists();
        }

        private void shopIdComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            ShowShoppingLists();
        }
    }
}