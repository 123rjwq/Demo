﻿namespace Shopping.AppUserControls
{
    partial class DiaryUserControl
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.inWorkAttentionBackground = new System.Windows.Forms.Button();
            this.amountLabel = new System.Windows.Forms.Label();
            this.locationLabel = new System.Windows.Forms.Label();
            this.dateLabel = new System.Windows.Forms.Label();
            this.workingHoursLabel = new System.Windows.Forms.Label();
            this.storeLabel = new System.Windows.Forms.Label();
            this.commentLabel = new System.Windows.Forms.Label();
            this.promoLabel = new System.Windows.Forms.Label();
            this.archiveButtonAttentionBackground = new System.Windows.Forms.Button();
            this.promoTextLabel = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // inWorkAttentionBackground
            // 
            this.inWorkAttentionBackground.Location = new System.Drawing.Point(1375, 160);
            this.inWorkAttentionBackground.Name = "inWorkAttentionBackground";
            this.inWorkAttentionBackground.Size = new System.Drawing.Size(232, 57);
            this.inWorkAttentionBackground.TabIndex = 11;
            this.inWorkAttentionBackground.Text = "Редактировать";
            this.inWorkAttentionBackground.UseVisualStyleBackColor = true;
            this.inWorkAttentionBackground.Click += new System.EventHandler(this.inWorkAttentionBackground_Click);
            // 
            // amountLabel
            // 
            this.amountLabel.Location = new System.Drawing.Point(1295, 30);
            this.amountLabel.Margin = new System.Windows.Forms.Padding(0);
            this.amountLabel.Name = "amountLabel";
            this.amountLabel.Size = new System.Drawing.Size(315, 25);
            this.amountLabel.TabIndex = 10;
            this.amountLabel.Text = "Позиций в списке: ";
            this.amountLabel.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.amountLabel.Click += new System.EventHandler(this.DiaryUserControl_Click);
            // 
            // locationLabel
            // 
            this.locationLabel.AutoSize = true;
            this.locationLabel.Location = new System.Drawing.Point(30, 195);
            this.locationLabel.Margin = new System.Windows.Forms.Padding(0);
            this.locationLabel.Name = "locationLabel";
            this.locationLabel.Size = new System.Drawing.Size(97, 25);
            this.locationLabel.TabIndex = 9;
            this.locationLabel.Text = "Локация";
            this.locationLabel.Click += new System.EventHandler(this.DiaryUserControl_Click);
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = true;
            this.dateLabel.Location = new System.Drawing.Point(30, 160);
            this.dateLabel.Margin = new System.Windows.Forms.Padding(0);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(62, 25);
            this.dateLabel.TabIndex = 8;
            this.dateLabel.Text = "Дата";
            this.dateLabel.Click += new System.EventHandler(this.DiaryUserControl_Click);
            // 
            // workingHoursLabel
            // 
            this.workingHoursLabel.AutoSize = true;
            this.workingHoursLabel.Location = new System.Drawing.Point(30, 59);
            this.workingHoursLabel.Margin = new System.Windows.Forms.Padding(0);
            this.workingHoursLabel.Name = "workingHoursLabel";
            this.workingHoursLabel.Size = new System.Drawing.Size(171, 25);
            this.workingHoursLabel.TabIndex = 7;
            this.workingHoursLabel.Text = "(режим работы)";
            this.workingHoursLabel.Click += new System.EventHandler(this.DiaryUserControl_Click);
            // 
            // storeLabel
            // 
            this.storeLabel.AutoSize = true;
            this.storeLabel.Location = new System.Drawing.Point(30, 30);
            this.storeLabel.Margin = new System.Windows.Forms.Padding(0);
            this.storeLabel.Name = "storeLabel";
            this.storeLabel.Size = new System.Drawing.Size(97, 25);
            this.storeLabel.TabIndex = 6;
            this.storeLabel.Text = "Магазин";
            this.storeLabel.Click += new System.EventHandler(this.DiaryUserControl_Click);
            // 
            // commentLabel
            // 
            this.commentLabel.AutoSize = true;
            this.commentLabel.Location = new System.Drawing.Point(570, 30);
            this.commentLabel.Margin = new System.Windows.Forms.Padding(0);
            this.commentLabel.Name = "commentLabel";
            this.commentLabel.Size = new System.Drawing.Size(150, 25);
            this.commentLabel.TabIndex = 12;
            this.commentLabel.Text = "Комментарий\r\n";
            this.commentLabel.Click += new System.EventHandler(this.DiaryUserControl_Click);
            // 
            // promoLabel
            // 
            this.promoLabel.AutoSize = true;
            this.promoLabel.Location = new System.Drawing.Point(692, 195);
            this.promoLabel.Margin = new System.Windows.Forms.Padding(0);
            this.promoLabel.Name = "promoLabel";
            this.promoLabel.Size = new System.Drawing.Size(125, 25);
            this.promoLabel.TabIndex = 13;
            this.promoLabel.Text = "Промокод: ";
            this.promoLabel.Click += new System.EventHandler(this.DiaryUserControl_Click);
            // 
            // archiveButtonAttentionBackground
            // 
            this.archiveButtonAttentionBackground.Location = new System.Drawing.Point(1375, 86);
            this.archiveButtonAttentionBackground.Name = "archiveButtonAttentionBackground";
            this.archiveButtonAttentionBackground.Size = new System.Drawing.Size(232, 57);
            this.archiveButtonAttentionBackground.TabIndex = 14;
            this.archiveButtonAttentionBackground.Text = "Архивировать";
            this.archiveButtonAttentionBackground.UseVisualStyleBackColor = true;
            this.archiveButtonAttentionBackground.Click += new System.EventHandler(this.archiveButtonAttentionBackground_Click);
            // 
            // promoTextLabel
            // 
            this.promoTextLabel.AutoSize = true;
            this.promoTextLabel.Location = new System.Drawing.Point(570, 195);
            this.promoTextLabel.Margin = new System.Windows.Forms.Padding(0);
            this.promoTextLabel.Name = "promoTextLabel";
            this.promoTextLabel.Size = new System.Drawing.Size(125, 25);
            this.promoTextLabel.TabIndex = 15;
            this.promoTextLabel.Text = "Промокод: ";
            this.promoTextLabel.Visible = false;
            this.promoTextLabel.Click += new System.EventHandler(this.DiaryUserControl_Click);
            // 
            // DiaryUserControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(12F, 25F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.Controls.Add(this.promoTextLabel);
            this.Controls.Add(this.archiveButtonAttentionBackground);
            this.Controls.Add(this.promoLabel);
            this.Controls.Add(this.commentLabel);
            this.Controls.Add(this.inWorkAttentionBackground);
            this.Controls.Add(this.amountLabel);
            this.Controls.Add(this.locationLabel);
            this.Controls.Add(this.dateLabel);
            this.Controls.Add(this.workingHoursLabel);
            this.Controls.Add(this.storeLabel);
            this.Name = "DiaryUserControl";
            this.Size = new System.Drawing.Size(1638, 248);
            this.Click += new System.EventHandler(this.DiaryUserControl_Click);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button inWorkAttentionBackground;
        private System.Windows.Forms.Label amountLabel;
        private System.Windows.Forms.Label locationLabel;
        private System.Windows.Forms.Label dateLabel;
        private System.Windows.Forms.Label workingHoursLabel;
        private System.Windows.Forms.Label storeLabel;
        private System.Windows.Forms.Label commentLabel;
        private System.Windows.Forms.Label promoLabel;
        private System.Windows.Forms.Button archiveButtonAttentionBackground;
        private System.Windows.Forms.Label promoTextLabel;
    }
}
