﻿using System;
using System.Data.Entity;
using System.Linq;
using System.Windows.Forms;
using Shopping.AppForms;
using Shopping.Models;

namespace Shopping.AppUserControls
{
    public partial class DiaryUserControl : UserControl
    {
        public event EventHandler ControlUpdated;
        private ShoppingList _shoppingList;

        public DiaryUserControl(ShoppingList shoppingList)
        {
            InitializeComponent();
            _shoppingList = shoppingList;
            SetLabels();
        }

        private void SetLabels()
        {
            var shop = _shoppingList.Shop;
            storeLabel.Text = $"{shop.Name} + {_shoppingList.IdList}";
            workingHoursLabel.Text = shop.WorkingHours;
            dateLabel.Text = _shoppingList.Date.ToLongDateString();
            locationLabel.Text = shop.Location;
            commentLabel.Text = _shoppingList.Comment;
            amountLabel.Text = $"Позиций в списке: {_shoppingList.ShoppingListItems.Count}";

            string promoCode = shop.PromoCodes.FirstOrDefault(p => p.ShopId == shop.IdShop)?.Code;
            promoLabel.Text = promoCode ?? string.Empty;
            promoTextLabel.Visible = !string.IsNullOrEmpty(promoCode);
        }

        private void archiveButtonAttentionBackground_Click(object sender, EventArgs e)
        {
            _shoppingList.Archived = true;
            Program.context.Entry(_shoppingList).State = EntityState.Modified;
            Program.context.SaveChanges();
            ControlUpdated?.Invoke(this, EventArgs.Empty);
        }

        private void OpenForm(Form form)
        {
            if (form.ShowDialog() == DialogResult.OK)
            {
                ((MainForm)Parent?.Parent?.Parent?.Parent)?.RefreshShoppingLists();
            }
        }

        private void inWorkAttentionBackground_Click(object sender, EventArgs e)
            => OpenForm(new ListForm(_shoppingList));

        private void DiaryUserControl_Click(object sender, EventArgs e)
            => OpenForm(new CreateUpdateListForm(_shoppingList));
    }
}