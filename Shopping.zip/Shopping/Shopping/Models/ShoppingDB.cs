using System;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Linq;

namespace Shopping.Models
{
    public partial class ShoppingDB : DbContext
    {
        public ShoppingDB()
            : base("name=ShoppingDB")
        {
        }

        public virtual DbSet<PromoCode> PromoCodes { get; set; }
        public virtual DbSet<ShoppingListItem> ShoppingListItems { get; set; }
        public virtual DbSet<ShoppingList> ShoppingLists { get; set; }
        public virtual DbSet<Shop> Shops { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Entity<ShoppingList>()
                .HasMany(e => e.ShoppingListItems)
                .WithRequired(e => e.ShoppingList)
                .HasForeignKey(e => e.ListId);

            modelBuilder.Entity<Shop>()
                .HasMany(e => e.PromoCodes)
                .WithRequired(e => e.Shop)
                .HasForeignKey(e => e.ShopId);

            modelBuilder.Entity<Shop>()
                .HasMany(e => e.ShoppingLists)
                .WithRequired(e => e.Shop)
                .HasForeignKey(e => e.ShopId);
        }
    }
}
