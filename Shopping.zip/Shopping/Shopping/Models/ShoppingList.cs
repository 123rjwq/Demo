namespace Shopping.Models
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class ShoppingList
    {
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2214:DoNotCallOverridableMethodsInConstructors")]
        public ShoppingList()
        {
            ShoppingListItems = new HashSet<ShoppingListItem>();
        }

        [Key]
        public int IdList { get; set; }

        public int ShopId { get; set; }

        [Column(TypeName = "date")]
        public DateTime Date { get; set; }

        public string Comment { get; set; }

        public bool? Archived { get; set; }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        public virtual ICollection<ShoppingListItem> ShoppingListItems { get; set; }

        public virtual Shop Shop { get; set; }

        public bool isNew()
        {
            return IdList == 0;
        }
    }
}
