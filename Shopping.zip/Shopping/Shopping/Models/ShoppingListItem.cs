using System.ComponentModel.DataAnnotations;

namespace Shopping.Models
{
    public partial class ShoppingListItem
    {
        [Key]
        public int IdItem { get; set; }

        public int ListId { get; set; }

        [Required]
        [StringLength(255)]
        public string Name { get; set; }

        public int Quantity { get; set; }

        public string Comment { get; set; }

        public virtual ShoppingList ShoppingList { get; set; }
    }
}
